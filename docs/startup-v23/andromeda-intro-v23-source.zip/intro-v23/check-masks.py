import json,io
import numpy as np
from PIL import Image
from fontTools.pens.boundsPen import BoundsPen
from fontTools.svgLib.path import parse_path
import cairosvg
from itertools import combinations
states=json.load(open('states.json'));geo=json.load(open('src/logo.json'));planet=json.load(open('src/planet.json'))
bounds=[]
for l in geo['letters']:
 p=BoundsPen(None);parse_path(l['path'],p);bounds.append(p.bounds)
def mask(path,transform,b):
 x0,y0,x1,y1=b;w=x1-x0;h=y1-y0
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {y0} {w} {h}" width="{w}" height="{h}"><path fill="white" d="{path}" transform="{transform}"/></svg>'
 return np.asarray(Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert('RGBA'))[:,:,3]>8
violations=[];emergences=[[] for _ in bounds];maxpairs=0
for f,st in enumerate(states):
 boxes=[]
 for i,m in enumerate(st['motions']):
  if not m['visible']:boxes.append(None);continue
  a,b,c,d=bounds[i];k=m['fs'];s=m['s'];x=m['x'];y=m['y']
  boxes.append((int(np.floor(x+a*k*s))-1,int(np.floor(y-d*k*m.get('sy',1/s)))-1,int(np.ceil(x+c*k*s))+1,int(np.ceil(y-b*k*m.get('sy',1/s)))+1))
 def pm(b):return mask(planet,f'translate({st["cx"]} {st["cy"]}) scale({st["size"]/100*st["ps"]} {st["size"]/100/st["ps"]}) translate(-50 -50)',b)
 for i,j in combinations(range(9),2):
  if boxes[i] is None or boxes[j] is None:continue
  a,b=boxes[i],boxes[j];r=(max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3]))
  if r[2]<=r[0] or r[3]<=r[1]:continue
  mi=mask(st['motions'][i]['path'],st['motions'][i]['t'],r);mj=mask(st['motions'][j]['path'],st['motions'][j]['t'],r)
  count=int(np.count_nonzero(mi & mj & ~pm(r)))
  if count:violations.append([f,i,j,count]);maxpairs=max(maxpairs,count)
 for i,m in enumerate(st['motions']):
  age=f-(6+(8-i)*8)
  if m['visible'] and age<21:
   b=boxes[i];letter=mask(m['path'],m['t'],b);pl=pm(b);hidden=int(np.count_nonzero(letter&pl));visible=int(np.count_nonzero(letter&~pl))
   if hidden and visible:emergences[i].append([f,hidden,visible])
print('Frames',len(states),'intersection violations',len(violations),'max pixels',maxpairs)
print('Partial emergence frames:',[len(x) for x in emergences]);print('First violations:',violations[:20])
json.dump({'violations':violations,'emergences':emergences,'frames':len(states)},open('mask-report.json','w'))
