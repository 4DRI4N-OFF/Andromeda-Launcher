exec(open('check-masks.py').read().split('violations=[]')[0])
occluder=json.load(open('src/occluder.json'));base=json.load(open('../intro-v17/states.json'));em=[[] for _ in range(9)]
for f,st in enumerate(states):
 assert all(st[k]==base[f][k] for k in ['cx','cy','size','ps'])
 shift=st['motions'][0]['x']-base[-1]['motions'][0]['x']
 for i,m in enumerate(st['motions']):
  assert abs(m['x']-base[-1]['motions'][i]['x']-shift)<1e-9
  assert m['s']==1 and m['sy']==1 and m['y']==base[-1]['motions'][i]['y']
  a,b,c,d=bounds[i];fs=m['fs'];x=m['x'];y=m['y'];box=(int(np.floor(x+a*fs))-1,int(np.floor(y-d*fs))-1,int(np.ceil(x+c*fs))+1,int(np.ceil(y-b*fs))+1)
  lm=mask(m['path'],m['t'],box);pm=mask(occluder,f'translate({st["cx"]} {st["cy"]}) scale({st["size"]/100}) translate(-50 -50)',box)
  pm[:,np.arange(box[0],box[2])<st['cx']]=True
  visible=int((lm&~pm).sum());hidden=int((lm&pm).sum());em[i].append([f,visible,hidden])
for i in range(9):
 assert em[i][0][1]==0
 assert any(v and h for _,v,h in em[i])
 assert states[-1]['motions'][i]['t']==base[-1]['motions'][i]['t']
# Fixed original spacing means no letter-pair intersections can arise under a common translation.
for i,j in combinations(range(9),2):
 a,b=bounds[i],bounds[j];mi,mj=states[-1]['motions'][i],states[-1]['motions'][j]
 x0=int(np.floor(min(mi['x']+a[0]*mi['fs'],mj['x']+b[0]*mj['fs'])))-1;x1=int(np.ceil(max(mi['x']+a[2]*mi['fs'],mj['x']+b[2]*mj['fs'])))+1
 box=(x0,450,x1,560)
 assert not (mask(mi['path'],mi['t'],box)&mask(mj['path'],mj['t'],box)).any(),(i,j)
r={'frames':126,'planet_exact_v17':True,'common_translation_error_max':'<1e-9px','fixed_final_sizes':True,'final_exact_v17':True,'all_begin_hidden':True,'all_partial_emergence':True,'pair_intersections':0,'first_visible_frames':[next(f for f,v,h in e if v) for e in em]}
json.dump(r,open('train-report.json','w'),indent=2);print(r)
from PIL import ImageDraw
sheet=Image.new('RGB',(1200,6*210),'#16141a');draw=ImageDraw.Draw(sheet)
for k,f in enumerate([44,48,52,56,60,64,68,72,76,82,88,94]):
 im=Image.open(f'review/{f+1:04}.png');im=im.crop((300,400,1500,600));im.thumbnail((600,180));x=k%2*600;y=k//2*210;sheet.paste(im,(x,y+25));draw.text((x+5,y+5),f'frame {f}',fill='white')
sheet.save('train-review.png')
