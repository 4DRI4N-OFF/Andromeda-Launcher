import React from 'react';
import {AbsoluteFill,Composition,registerRoot,spring,useCurrentFrame} from 'remotion';
import geo from './logo.json';import planet from './planet.json';import occluder from './occluder.json';
const clamp=(x:number,a:number,b:number)=>Math.max(a,Math.min(b,x));
const ease=(x:number)=>{const t=clamp(x,0,1);return t*t*t*(t*(t*6-15)+10)};
export const state=(f:number)=>{
 const q=ease(f/94),fc=(geo.planetX+geo.planetSize/2)*geo.scale+geo.offsetX,fy=(geo.planetY+geo.planetSize/2)*geo.scale+geo.offsetY;
 const cx=960+(fc-960)*q,cy=540+(fy-540)*q,size=650+(geo.planetSize*geo.scale-650)*q;
 const fs=geo.fontScale*geo.scale,baseline=geo.baseline*geo.scale+geo.offsetY,tx=geo.textX*geo.scale+geo.offsetX;
 const centers=[53.22976030639649,54.0417192553711,53.31881640869141,49.848723897705085,53.65248998535157,68.72270494873048,44.02082712402344,53.31881640869141,53.22976030639649];
 const train=ease(f/94),shift=-1120*(1-train);
 const motions=geo.letters.map((l,i)=>{
  const x=tx+l.x*fs+shift,y=baseline;
  return {visible:true,path:l.path,x,y,s:1,sy:1,fs,t:`translate(${x} ${y}) scale(${fs} ${-fs})`};
 });return {cx,cy,size,ps:1,motions};
};
const Intro:React.FC=()=>{const f=useCurrentFrame(),{cx,cy,size,motions}=state(f);return <AbsoluteFill style={{background:'#080611'}}><div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at 50% 47%, #201638 0%,#100b20 45%,#080611 80%)'}}/><svg width="1920" height="1080" viewBox="0 0 1920 1080" style={{position:'absolute'}}><defs><mask id="behind"><rect width="1920" height="1080" fill="white"/><rect x="0" y="0" width={cx} height="1080" fill="black"/><path fill="black" stroke="black" strokeWidth="0.25" d={occluder} transform={`translate(${cx} ${cy}) scale(${size/100}) translate(-50 -50)`}/></mask></defs><g fill="white" mask="url(#behind)">{motions.map((m,i)=>m.visible&&<path key={i} d={m.path} transform={m.t}/>)}</g><path fill="white" d={planet} transform={`translate(${cx} ${cy}) scale(${size/100}) translate(-50 -50)`}/></svg></AbsoluteFill>};
registerRoot(()=> <Composition id="AndromedaIntroV23" component={Intro} durationInFrames={126} fps={60} width={1920} height={1080}/>);
