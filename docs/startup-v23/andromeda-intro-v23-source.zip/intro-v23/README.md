# Andromeda intro v23 - train interpretation

Silent1920x1080,60fps,126frames,2.1seconds. Planet and background exact v17. Original final paths, E and final transforms unchanged. No impacts, spring, squash/stretch, opacity fades or independent letter delays.

A rigid row of glyphs,at final original sizes and original final spacing,moves together by one common horizontal translation: -1120*(1-ease(frame/94)). Ease is quintic smootherstep. All nine glyphs have identical instantaneous velocity and brake together. Last32frames hold. Their order is unchanged: last A exits the planet first. Letters are never individually switched visible. They are revealed by a mask: original planet outer contour plus hidden left-back halfplane ending at planet center. The extra back mask prevents the long row showing on the left of the planet.

Differences from v17: letters use final sizes throughout rather than individual20%-100% growth/vertical settling; no per-letter spawn schedule. Additional left-back mask. The planet retains its exact v17 path and shrink timing. First visible pixels by letter ANDROMEDA: frames72,67,63,60,57,52,50,48,44. These are geometric exits,not animation delays. All126encodedframes visually reviewed,plus enlarged emergence and final. Verifier checks exact planet state allframes,common displacement,fixed sizes,allhiddenatstart,partialemergenceforall,zero pair intersections,and original final transforms.

Build: npm ci; npx remotion render src/index.tsx AndromedaIntroV23 andromeda-intro-v23.mp4 --concurrency=2
States: npx esbuild src/check-state.ts --bundle --platform=node --outfile=state.cjs; node state.cjs
verify-train.py uses ../intro-v17/states.json as comparison fixture. Python requirements Pillow,numpy,fontTools,cairosvg. check-masks.py included only for mask utility functions,not its old v17 main tests.
